//
//  SecondViewController.h
//  NendSDKTestTabBase
//
//  Created by ユウゲンガイシャ クレエ on 11/07/25.
//  Modify by F@N Communications, Inc. on 12/06/22.
//  
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NADView.h"

@interface SecondViewController : UIViewController<NADViewDelegate> {
}

@end

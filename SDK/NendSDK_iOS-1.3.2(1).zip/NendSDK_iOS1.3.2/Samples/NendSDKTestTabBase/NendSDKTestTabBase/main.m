//
//  main.m
//  NendSDKTestTabBase
//
//  Created by ユウゲンガイシャ クレエ on 11/07/25.
//  Modify by F@N Communications, Inc. on 12/06/22.
//  
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}

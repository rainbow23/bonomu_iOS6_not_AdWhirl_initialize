//
//  NendSDKTestARCAppDelegate.h
//  NendSDKTestARC
//
//  Created by ADN on 12/06/07.
//  Copyright (c) 2012 F@N Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NendSDKTestARCViewController;

@interface NendSDKTestARCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) NendSDKTestARCViewController *viewController;

@end

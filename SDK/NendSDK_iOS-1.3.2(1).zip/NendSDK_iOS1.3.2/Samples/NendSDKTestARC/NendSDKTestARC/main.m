//
//  main.m
//  NendSDKTestARC
//
//  Created by ADN on 12/06/07.
//  Copyright (c) 2012 F@N Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NendSDKTestARCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NendSDKTestARCAppDelegate class]));
    }
}

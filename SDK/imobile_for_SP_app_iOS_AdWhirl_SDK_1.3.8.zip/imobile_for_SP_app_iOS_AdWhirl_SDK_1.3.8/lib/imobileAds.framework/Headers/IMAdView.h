//
//  IMobileAdView.h
//  imobileAds
//
//  Copyright 2011 i-mobile Co.Ltd. All rights reserved.
//
// 過去Verの互換性のためにだけに残しています。
// 特別な理由がない限り、IMobileAdView.h を直接インポートしてください。

#import "IMobileAdView.h"

@compatibility_alias    IMAdView    IMobileAdView;
